export default function Custom404() {
  return <h1>404 - Nosso arquivo do curso</h1>
}
